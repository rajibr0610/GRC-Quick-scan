import { NextResponse } from "next/server";
import Whop from "@whop/sdk";
import { supabaseAdmin } from "@/lib/supabase";

export async function POST(request: Request) {
  try {
    const secret = process.env.WHOP_WEBHOOK_SECRET;
    const apiKey = process.env.WHOP_API_KEY;
    if (!secret || !apiKey) return new Response("Webhook not configured", { status: 500 });

    const whop = new Whop({
      apiKey,
      webhookKey: btoa(secret)
    });

    const body = await request.text();
    const headers = Object.fromEntries(request.headers);
    const event = whop.webhooks.unwrap(body, { headers });

    if (event.type === "payment.succeeded") {
      const payment: any = event.data;
      const assessmentId = payment?.metadata?.assessment_id;

      if (assessmentId) {
        const db = supabaseAdmin();
        await db.from("assessments").update({
          paid: true,
          whop_payment_id: payment.id
        }).eq("id", assessmentId);
      }
    }

    return new Response("OK", { status: 200 });
  } catch (e) {
    console.error("Whop webhook error", e);
    return new Response("Invalid webhook", { status: 400 });
  }
}
